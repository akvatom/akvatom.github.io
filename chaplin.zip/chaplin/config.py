#TELEGRAM_TOKEN = "856060491:AAFRYNfWNAw1ZT019xwXAOr-gRmd4k46c64"
TELEGRAM_TOKEN = "5605488636:AAEP6hTe4mop-NvBhGjqVTWZdxMjmOgYSSI"
USERS_FIELDS = [
    ["id", "TEXT"], 
    ["name", "TEXT"], 
    ["phone", "TEXT"],
    ["lang","TEXT"]]
SYSTEM = {
    "user" : {
        "id" : "id",
        "name" : "name",
        "phone" : "phone",
        "lang" : "lang"
    }
}
LANGS = [
    {
        "text" : "🇷🇺 Русский",
        "value" : "ru",
    },
    {
        "text" : "🇺🇿 O'zbek",
        "value" : "uz",
    },    
    {
        "text" : "🇬🇧 English",
        "value" : "en",
    },    
]

PAYMENT = {
    "click" : "TOKEN",
    "payme" : "TOKEN"
}

MY_LOCATION_1 = (39.669588, 66.939228)


LOCATION_NAME = {
    "1" : "улица Навоий шох 53А",
}

CHANEL = -1001933748308